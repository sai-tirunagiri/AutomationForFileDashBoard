package org.quinnox.verifyLogin;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class LoginTest {

	@Test
	public void verifyLogin() throws InterruptedException {
		WebDriver driver = new FirefoxDriver();
		
		driver.get("http://localhost:8087/FileDashBoard/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.findElement(By.className("abcRioButtonContentWrapper")).click();
		
		Set<String> windowID = driver.getWindowHandles();
		Iterator<String> itr = windowID.iterator();
		
		String parentWindowId = itr.next();
		String childWindowId = itr.next();
		
		
		System.out.println(parentWindowId);
		System.out.println(childWindowId);
		
		driver.switchTo().window(childWindowId);
		
		driver.findElement(By.id("Email")).sendKeys("manju.naidu13@gmail.com");
		driver.findElement(By.id("Passwd")).sendKeys("7411677660");
		driver.findElement(By.id("signIn")).click();
		
		System.out.println("PASS");
	}

}
